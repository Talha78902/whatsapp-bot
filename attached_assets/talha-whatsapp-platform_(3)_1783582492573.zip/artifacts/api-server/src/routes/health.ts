import { Router, type IRouter } from "express";
import { HealthCheckResponse } from "@workspace/api-zod";
import fs from "fs";
import path from "path";

const router: IRouter = Router();

router.get("/healthz", (_req, res) => {
  const data = HealthCheckResponse.parse({ status: "ok" });
  res.json(data);
});

// Temporary code download endpoint
router.get("/download/source", (_req, res) => {
  const filePath = "/tmp/talha-whatsapp-platform.zip";
  if (!fs.existsSync(filePath)) {
    res.status(404).json({ error: "File not found. Please regenerate." });
    return;
  }
  res.setHeader("Content-Disposition", 'attachment; filename="talha-whatsapp-platform.zip"');
  res.setHeader("Content-Type", "application/zip");
  res.setHeader("Content-Length", fs.statSync(filePath).size);
  fs.createReadStream(filePath).pipe(res);
});

export default router;
