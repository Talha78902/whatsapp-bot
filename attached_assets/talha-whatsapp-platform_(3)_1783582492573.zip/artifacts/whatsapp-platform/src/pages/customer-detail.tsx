import React, { useState } from 'react';
import { useRoute } from 'wouter';
import { useGetCustomer, useUpdateCustomer, useGetCustomerNotes, useAddCustomerNote, getGetCustomerNotesQueryKey, getGetCustomerQueryKey } from '@workspace/api-client-react';
import { useQueryClient } from '@tanstack/react-query';
import { AppLayout } from '../components/layout';
import { Card, CardHeader, CardTitle, CardContent, Badge, Button, Textarea } from '../components/ui-elements';
import { User, Phone, Mail, Clock, Activity, Tag, Plus } from 'lucide-react';

export function CustomerDetail() {
  const [, params] = useRoute('/customers/:id');
  const customerId = Number(params?.id);
  const queryClient = useQueryClient();

  const { data: customer, isLoading } = useGetCustomer(customerId, {
    query: { enabled: !!customerId, queryKey: getGetCustomerQueryKey(customerId) }
  });
  
  const { data: notes } = useGetCustomerNotes(customerId, {
    query: { enabled: !!customerId, queryKey: getGetCustomerNotesQueryKey(customerId) }
  });

  const [newNote, setNewNote] = useState('');
  
  const addNoteMutation = useAddCustomerNote({
    mutation: {
      onSuccess: () => {
        setNewNote('');
        queryClient.invalidateQueries({ queryKey: getGetCustomerNotesQueryKey(customerId) });
      }
    }
  });

  const handleAddNote = () => {
    if (!newNote.trim()) return;
    addNoteMutation.mutate({ id: customerId, data: { content: newNote } });
  };

  if (isLoading) {
    return <AppLayout><div className="p-8">Loading customer details...</div></AppLayout>;
  }

  if (!customer) {
    return <AppLayout><div className="p-8">Customer not found.</div></AppLayout>;
  }

  return (
    <AppLayout>
      <div className="p-8 max-w-5xl mx-auto space-y-6">
        <div className="flex items-start justify-between">
          <div className="flex items-center gap-4">
            <div className="w-16 h-16 bg-primary/10 rounded-sm flex items-center justify-center text-primary border border-primary/20">
              <User className="w-8 h-8" />
            </div>
            <div>
              <h1 className="text-2xl font-bold tracking-tight">{customer.name}</h1>
              <div className="flex items-center gap-2 mt-1">
                <Badge variant={
                  customer.status === 'active' ? 'success' : 
                  customer.status === 'blocked' ? 'destructive' : 'secondary'
                }>
                  {customer.status}
                </Badge>
                <span className="text-sm text-muted-foreground flex items-center gap-1">
                  <Clock className="w-3 h-3" />
                  Added {new Date(customer.createdAt).toLocaleDateString()}
                </span>
              </div>
            </div>
          </div>
          <Button variant="outline">Edit Profile</Button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="md:col-span-1 space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="text-sm">Contact Info</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center gap-3 text-sm">
                  <Phone className="w-4 h-4 text-muted-foreground" />
                  <span className="font-mono">{customer.phone}</span>
                </div>
                {customer.email && (
                  <div className="flex items-center gap-3 text-sm">
                    <Mail className="w-4 h-4 text-muted-foreground" />
                    <span>{customer.email}</span>
                  </div>
                )}
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="text-sm">Tags</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex flex-wrap gap-2">
                  {customer.tags?.map(tag => (
                    <Badge key={tag} variant="secondary" className="flex items-center gap-1">
                      <Tag className="w-3 h-3" /> {tag}
                    </Badge>
                  ))}
                  {(!customer.tags || customer.tags.length === 0) && (
                    <span className="text-sm text-muted-foreground">No tags assigned.</span>
                  )}
                </div>
              </CardContent>
            </Card>
          </div>

          <div className="md:col-span-2 space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="text-sm">Notes & History</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4 mb-6">
                  <Textarea 
                    placeholder="Add a note about this customer..." 
                    value={newNote}
                    onChange={(e) => setNewNote(e.target.value)}
                  />
                  <div className="flex justify-end">
                    <Button 
                      size="sm" 
                      onClick={handleAddNote}
                      disabled={addNoteMutation.isPending || !newNote.trim()}
                    >
                      <Plus className="w-4 h-4 mr-1" /> Add Note
                    </Button>
                  </div>
                </div>

                <div className="space-y-4 border-t border-card-border pt-4">
                  {notes && notes.length > 0 ? notes.map(note => (
                    <div key={note.id} className="bg-muted/50 p-4 rounded-sm border border-card-border">
                      <p className="text-sm">{note.content}</p>
                      <div className="text-xs text-muted-foreground mt-2 flex items-center gap-1">
                        <Activity className="w-3 h-3" />
                        {new Date(note.createdAt).toLocaleString()}
                      </div>
                    </div>
                  )) : (
                    <div className="text-center py-8 text-sm text-muted-foreground">
                      No notes yet. Add one above.
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </AppLayout>
  );
}
