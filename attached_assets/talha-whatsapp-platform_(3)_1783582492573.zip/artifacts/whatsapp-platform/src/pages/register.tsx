import React, { useState } from 'react';
import { useLocation, Link } from 'wouter';
import { useRegister, RegisterInputRole } from '@workspace/api-client-react';
import { AuthLayout } from '../components/layout';
import { Button, Input } from '../components/ui-elements';

export function Register() {
  const [, setLocation] = useLocation();
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  
  const registerMutation = useRegister({
    mutation: {
      onSuccess: (data) => {
        localStorage.setItem('access_token', data.accessToken);
        setLocation('/');
      },
      onError: (err: any) => {
        setError(err.message || 'Failed to register');
      }
    }
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    registerMutation.mutate({ data: { name, email, password, role: RegisterInputRole.manager } });
  };

  return (
    <AuthLayout>
      <div className="mb-6">
        <h2 className="text-xl font-semibold mb-1">Create Account</h2>
        <p className="text-sm text-muted-foreground">Request access to the command center.</p>
      </div>
      
      <form onSubmit={handleSubmit} className="space-y-4">
        {error && (
          <div className="bg-destructive/10 text-destructive px-3 py-2 rounded-sm text-sm border border-destructive/20">
            {error}
          </div>
        )}
        <div className="space-y-2">
          <label className="text-sm font-medium">Full Name</label>
          <Input 
            value={name} 
            onChange={(e) => setName(e.target.value)} 
            placeholder="Jane Doe"
            required 
            minLength={2}
          />
        </div>
        <div className="space-y-2">
          <label className="text-sm font-medium">Email Address</label>
          <Input 
            type="email" 
            value={email} 
            onChange={(e) => setEmail(e.target.value)} 
            placeholder="jane@example.com"
            required 
          />
        </div>
        <div className="space-y-2">
          <label className="text-sm font-medium">Password</label>
          <Input 
            type="password" 
            value={password} 
            onChange={(e) => setPassword(e.target.value)} 
            required 
            minLength={8}
          />
        </div>
        <Button type="submit" className="w-full" disabled={registerMutation.isPending}>
          {registerMutation.isPending ? 'Registering...' : 'Request Access'}
        </Button>
      </form>
      
      <div className="mt-6 text-center text-sm">
        <span className="text-muted-foreground">Already have an account? </span>
        <Link href="/login" className="text-primary font-medium hover:underline">Sign In</Link>
      </div>
    </AuthLayout>
  );
}
