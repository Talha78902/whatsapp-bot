import React, { useState, useEffect } from 'react';
import { useGetSettings, useUpdateWhatsappSettings, useUpdateAiSettings } from '@workspace/api-client-react';
import { AppLayout } from '../components/layout';
import { Card, CardHeader, CardTitle, CardContent, Button, Input, Textarea, Badge } from '../components/ui-elements';

export function Settings() {
  const { data, isLoading } = useGetSettings();
  const [activeTab, setActiveTab] = useState('whatsapp');

  const updateWaMutation = useUpdateWhatsappSettings();
  const updateAiMutation = useUpdateAiSettings();

  const [waData, setWaData] = useState({ phoneNumberId: '', businessAccountId: '', accessToken: '' });
  const [aiData, setAiData] = useState({ isEnabled: false, systemPrompt: '', model: '' });

  useEffect(() => {
    if (data) {
      setWaData({
        phoneNumberId: data.whatsapp.phoneNumberId || '',
        businessAccountId: data.whatsapp.businessAccountId || '',
        accessToken: data.whatsapp.accessToken ? '********' : '' // obfuscated if exists
      });
      setAiData({
        isEnabled: data.ai.isEnabled || false,
        systemPrompt: data.ai.systemPrompt || '',
        model: data.ai.model || 'gpt-4o-mini'
      });
    }
  }, [data]);

  const handleWaSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const payload = { ...waData };
    if (payload.accessToken === '********') delete payload.accessToken;
    updateWaMutation.mutate({ data: payload });
  };

  const handleAiSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    updateAiMutation.mutate({ data: aiData });
  };

  if (isLoading) return <AppLayout><div className="p-8">Loading settings...</div></AppLayout>;

  return (
    <AppLayout>
      <div className="p-8 max-w-4xl mx-auto space-y-8">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Settings</h1>
          <p className="text-muted-foreground text-sm mt-1">Configure platform integrations and AI behaviors.</p>
        </div>

        <div className="flex border-b border-border">
          <button 
            className={`px-4 py-2 font-medium text-sm border-b-2 transition-colors ${activeTab === 'whatsapp' ? 'border-primary text-foreground' : 'border-transparent text-muted-foreground hover:text-foreground'}`}
            onClick={() => setActiveTab('whatsapp')}
          >
            WhatsApp API
          </button>
          <button 
            className={`px-4 py-2 font-medium text-sm border-b-2 transition-colors ${activeTab === 'ai' ? 'border-primary text-foreground' : 'border-transparent text-muted-foreground hover:text-foreground'}`}
            onClick={() => setActiveTab('ai')}
          >
            AI Assistant
          </button>
        </div>

        {activeTab === 'whatsapp' && (
          <form onSubmit={handleWaSubmit} className="space-y-6 animate-in fade-in">
            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle>Meta Graph API Configuration</CardTitle>
                  <Badge variant={data?.whatsapp.isConfigured ? 'success' : 'destructive'}>
                    {data?.whatsapp.isConfigured ? 'Configured' : 'Missing Config'}
                  </Badge>
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <label className="text-sm font-medium">Phone Number ID</label>
                  <Input 
                    value={waData.phoneNumberId} 
                    onChange={e => setWaData(prev => ({...prev, phoneNumberId: e.target.value}))}
                    placeholder="101234567890123"
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-medium">WhatsApp Business Account ID</label>
                  <Input 
                    value={waData.businessAccountId} 
                    onChange={e => setWaData(prev => ({...prev, businessAccountId: e.target.value}))}
                    placeholder="101234567890123"
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-medium">Permanent Access Token</label>
                  <Input 
                    type="password"
                    value={waData.accessToken} 
                    onChange={e => setWaData(prev => ({...prev, accessToken: e.target.value}))}
                    placeholder="EAAG..."
                  />
                </div>
                <div className="pt-4 border-t border-border mt-4">
                  <label className="text-sm font-medium block mb-2">Webhook Details (Read Only)</label>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <span className="text-xs text-muted-foreground">Webhook URL</span>
                      <code className="block p-2 bg-muted rounded-sm text-xs mt-1">https://your-domain.com/api/webhook</code>
                    </div>
                    <div>
                      <span className="text-xs text-muted-foreground">Verify Token</span>
                      <code className="block p-2 bg-muted rounded-sm text-xs mt-1">{data?.whatsapp.webhookVerifyToken || 'Not generated yet'}</code>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
            <div className="flex justify-end">
              <Button type="submit" disabled={updateWaMutation.isPending}>
                {updateWaMutation.isPending ? 'Saving...' : 'Save Configuration'}
              </Button>
            </div>
          </form>
        )}

        {activeTab === 'ai' && (
          <form onSubmit={handleAiSubmit} className="space-y-6 animate-in fade-in">
            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle>AI Auto-Responder</CardTitle>
                  <div className="flex items-center gap-2">
                    <span className="text-sm font-medium">Enable AI</span>
                    <button 
                      type="button"
                      role="switch" 
                      className={`w-10 h-6 rounded-full relative transition-colors ${aiData.isEnabled ? 'bg-primary' : 'bg-muted'}`}
                      onClick={() => setAiData(prev => ({...prev, isEnabled: !prev.isEnabled}))}
                    >
                      <span className={`block w-4 h-4 rounded-full bg-white absolute top-1 transition-transform ${aiData.isEnabled ? 'left-5' : 'left-1'}`} />
                    </button>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <label className="text-sm font-medium">Model</label>
                  <select 
                    className="flex h-9 w-full rounded-sm border border-input bg-transparent px-3 py-1 text-sm shadow-sm"
                    value={aiData.model}
                    onChange={e => setAiData(prev => ({...prev, model: e.target.value}))}
                    disabled={!aiData.isEnabled}
                  >
                    <option value="gpt-4o-mini">GPT-4o Mini (Fast & Cheap)</option>
                    <option value="gpt-4o">GPT-4o (Smart & Accurate)</option>
                  </select>
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-medium">System Prompt</label>
                  <Textarea 
                    className="min-h-[200px] font-mono text-sm leading-relaxed"
                    value={aiData.systemPrompt}
                    onChange={e => setAiData(prev => ({...prev, systemPrompt: e.target.value}))}
                    disabled={!aiData.isEnabled}
                    placeholder="You are a helpful customer support agent for..."
                  />
                  <p className="text-xs text-muted-foreground">Define the AI's persona, constraints, and knowledge base here.</p>
                </div>
              </CardContent>
            </Card>
            <div className="flex justify-end">
              <Button type="submit" disabled={updateAiMutation.isPending || !aiData.isEnabled && data?.ai.isEnabled === false}>
                {updateAiMutation.isPending ? 'Saving...' : 'Save AI Settings'}
              </Button>
            </div>
          </form>
        )}
      </div>
    </AppLayout>
  );
}
