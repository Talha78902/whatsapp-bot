import React, { useState } from 'react';
import { useRoute } from 'wouter';
import { useGetCampaign, useGetCampaignAnalytics, useScheduleCampaign, getGetCampaignQueryKey, getGetCampaignAnalyticsQueryKey } from '@workspace/api-client-react';
import { useQueryClient } from '@tanstack/react-query';
import { AppLayout } from '../components/layout';
import { Card, CardHeader, CardTitle, CardContent, Badge, Button, Input } from '../components/ui-elements';
import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip as RechartsTooltip, LineChart, Line, XAxis, YAxis, CartesianGrid } from 'recharts';
import { Calendar, Play, Clock, CheckCircle2, AlertTriangle, FileText } from 'lucide-react';

export function CampaignDetail() {
  const [, params] = useRoute('/campaigns/:id');
  const campaignId = Number(params?.id);
  const queryClient = useQueryClient();

  const { data: campaign, isLoading } = useGetCampaign(campaignId, {
    query: { enabled: !!campaignId, queryKey: getGetCampaignQueryKey(campaignId) }
  });

  const { data: analytics } = useGetCampaignAnalytics(campaignId, {
    query: { enabled: !!campaignId, queryKey: getGetCampaignAnalyticsQueryKey(campaignId) }
  });

  const [scheduleDate, setScheduleDate] = useState('');
  
  const scheduleMutation = useScheduleCampaign({
    mutation: {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getGetCampaignQueryKey(campaignId) });
      }
    }
  });

  const handleLaunch = (sendNow: boolean) => {
    scheduleMutation.mutate({ 
      id: campaignId, 
      data: { 
        scheduledAt: sendNow ? new Date().toISOString() : new Date(scheduleDate).toISOString(),
        recipientTags: campaign?.tags || [],
        sendNow
      } 
    });
  };

  if (isLoading) return <AppLayout><div className="p-8">Loading...</div></AppLayout>;
  if (!campaign) return <AppLayout><div className="p-8">Campaign not found</div></AppLayout>;

  const hasStarted = ['running', 'completed', 'paused'].includes(campaign.status);

  return (
    <AppLayout>
      <div className="p-8 max-w-6xl mx-auto space-y-6">
        <div className="flex items-start justify-between">
          <div>
            <div className="flex items-center gap-3">
              <h1 className="text-2xl font-bold tracking-tight">{campaign.name}</h1>
              <Badge variant={
                campaign.status === 'running' ? 'success' : 
                campaign.status === 'completed' ? 'default' :
                campaign.status === 'draft' ? 'secondary' : 'warning'
              }>
                {campaign.status}
              </Badge>
            </div>
            <p className="text-muted-foreground text-sm mt-1">{campaign.description || 'No description provided.'}</p>
          </div>
        </div>

        {campaign.status === 'draft' && (
          <Card className="border-primary/20 bg-primary/5">
            <CardContent className="p-6 flex flex-col md:flex-row gap-6 items-center justify-between">
              <div>
                <h3 className="font-semibold text-lg flex items-center gap-2">
                  <Play className="w-5 h-5 text-primary" /> Ready to Launch
                </h3>
                <p className="text-sm text-muted-foreground mt-1">
                  This campaign is currently a draft. You can launch it immediately or schedule it for later.
                </p>
              </div>
              <div className="flex flex-col sm:flex-row items-center gap-3 w-full md:w-auto">
                <Button onClick={() => handleLaunch(true)} disabled={scheduleMutation.isPending} className="w-full sm:w-auto">
                  Launch Now
                </Button>
                <div className="flex gap-2 w-full sm:w-auto">
                  <Input 
                    type="datetime-local" 
                    value={scheduleDate} 
                    onChange={e => setScheduleDate(e.target.value)} 
                    className="w-full sm:w-auto"
                  />
                  <Button variant="outline" onClick={() => handleLaunch(false)} disabled={!scheduleDate || scheduleMutation.isPending}>
                    Schedule
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        )}

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <Card className="md:col-span-2">
            <CardHeader>
              <CardTitle>Delivery Funnel</CardTitle>
            </CardHeader>
            <CardContent>
              {hasStarted ? (
                <div className="grid grid-cols-4 gap-4 mb-8">
                  <FunnelStep label="Targeted" value={campaign.recipientCount || 0} color="bg-gray-200 text-gray-800" />
                  <FunnelStep label="Sent" value={campaign.sentCount || 0} color="bg-blue-100 text-blue-800" />
                  <FunnelStep label="Delivered" value={campaign.deliveredCount || 0} color="bg-indigo-100 text-indigo-800" />
                  <FunnelStep label="Read" value={campaign.readCount || 0} color="bg-emerald-100 text-emerald-800" />
                </div>
              ) : (
                <div className="py-12 text-center text-muted-foreground text-sm border border-dashed border-border rounded-sm">
                  Metrics will appear once the campaign starts.
                </div>
              )}

              {analytics?.timeline && analytics.timeline.length > 0 && (
                <div className="h-64 mt-6">
                  <h4 className="text-sm font-medium mb-4">Performance Timeline</h4>
                  <ResponsiveContainer width="100%" height="100%">
                    <LineChart data={analytics.timeline}>
                      <CartesianGrid strokeDasharray="3 3" vertical={false} />
                      <XAxis dataKey="time" tick={{fontSize: 12}} />
                      <YAxis tick={{fontSize: 12}} />
                      <RechartsTooltip />
                      <Line type="monotone" dataKey="sent" stroke="#94a3b8" />
                      <Line type="monotone" dataKey="delivered" stroke="#6366f1" />
                      <Line type="monotone" dataKey="read" stroke="#10b981" strokeWidth={2} />
                    </LineChart>
                  </ResponsiveContainer>
                </div>
              )}
            </CardContent>
          </Card>

          <div className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Campaign Config</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center gap-3">
                  <FileText className="w-4 h-4 text-muted-foreground shrink-0" />
                  <div className="text-sm">
                    <span className="font-medium block">Message Type</span>
                    <span className="text-muted-foreground capitalize">{campaign.type}</span>
                  </div>
                </div>
                {campaign.scheduledAt && (
                  <div className="flex items-center gap-3">
                    <Calendar className="w-4 h-4 text-muted-foreground shrink-0" />
                    <div className="text-sm">
                      <span className="font-medium block">Scheduled For</span>
                      <span className="text-muted-foreground">{new Date(campaign.scheduledAt).toLocaleString()}</span>
                    </div>
                  </div>
                )}
                {campaign.startedAt && (
                  <div className="flex items-center gap-3">
                    <Clock className="w-4 h-4 text-muted-foreground shrink-0" />
                    <div className="text-sm">
                      <span className="font-medium block">Started At</span>
                      <span className="text-muted-foreground">{new Date(campaign.startedAt).toLocaleString()}</span>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {hasStarted && (
              <Card>
                <CardHeader>
                  <CardTitle>Delivery Health</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="h-40 relative">
                    <ResponsiveContainer width="100%" height="100%">
                      <PieChart>
                        <Pie
                          data={[
                            { name: 'Delivered', value: campaign.deliveredCount || 0 },
                            { name: 'Failed', value: campaign.failedCount || 0 }
                          ]}
                          innerRadius={40}
                          outerRadius={60}
                          dataKey="value"
                        >
                          <Cell fill="#10b981" />
                          <Cell fill="#ef4444" />
                        </Pie>
                        <RechartsTooltip />
                      </PieChart>
                    </ResponsiveContainer>
                    <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none">
                      <span className="text-xl font-bold font-mono">
                        {campaign.sentCount ? Math.round(((campaign.deliveredCount || 0)/campaign.sentCount)*100) : 0}%
                      </span>
                    </div>
                  </div>
                  <div className="flex justify-between mt-2 text-sm">
                    <div className="flex items-center gap-1"><div className="w-2 h-2 rounded-full bg-emerald-500"></div> Delivered</div>
                    <div className="flex items-center gap-1"><div className="w-2 h-2 rounded-full bg-red-500"></div> Failed ({campaign.failedCount || 0})</div>
                  </div>
                </CardContent>
              </Card>
            )}
          </div>
        </div>
      </div>
    </AppLayout>
  );
}

function FunnelStep({ label, value, color }: { label: string, value: number, color: string }) {
  return (
    <div className={`p-4 rounded-sm flex flex-col items-center justify-center text-center ${color}`}>
      <span className="text-xs font-semibold uppercase tracking-wider mb-1 opacity-80">{label}</span>
      <span className="text-2xl font-bold font-mono">{value.toLocaleString()}</span>
    </div>
  );
}
