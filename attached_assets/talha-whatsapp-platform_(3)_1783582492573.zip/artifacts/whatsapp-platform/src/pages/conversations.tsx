import React, { useState } from 'react';
import { useLocation } from 'wouter';
import { useListConversations, ListConversationsStatus } from '@workspace/api-client-react';
import { AppLayout } from '../components/layout';
import { Badge, Input, Card } from '../components/ui-elements';
import { Search, Bot, User, MessageSquare } from 'lucide-react';

export function Conversations() {
  const [, setLocation] = useLocation();
  const [search, setSearch] = useState('');
  const [status, setStatus] = useState<ListConversationsStatus | 'all'>('all');

  const { data, isLoading } = useListConversations({
    search: search || undefined,
    status: status === 'all' ? undefined : status,
    limit: 20
  });

  return (
    <AppLayout>
      <div className="flex h-screen overflow-hidden">
        {/* Inbox Sidebar List */}
        <div className="w-full md:w-96 border-r border-sidebar-border bg-sidebar/5 flex flex-col h-full">
          <div className="p-4 border-b border-sidebar-border bg-background space-y-4">
            <h1 className="text-xl font-bold tracking-tight">Inbox</h1>
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
              <Input 
                placeholder="Search conversations..." 
                className="pl-9 bg-card"
                value={search}
                onChange={e => setSearch(e.target.value)}
              />
            </div>
            <div className="flex gap-2 overflow-x-auto pb-1 no-scrollbar">
              {['all', 'open', 'ai_handled', 'human_handled', 'closed'].map(s => (
                <button
                  key={s}
                  onClick={() => setStatus(s as any)}
                  className={`px-3 py-1 text-xs font-medium rounded-full transition-colors whitespace-nowrap ${
                    status === s ? 'bg-primary text-primary-foreground' : 'bg-muted text-muted-foreground hover:bg-muted/80'
                  }`}
                >
                  {s.replace('_', ' ').toUpperCase()}
                </button>
              ))}
            </div>
          </div>

          <div className="flex-1 overflow-y-auto">
            {isLoading ? (
              <div className="p-8 text-center text-muted-foreground text-sm">Loading inbox...</div>
            ) : data?.data?.length === 0 ? (
              <div className="p-8 text-center flex flex-col items-center gap-2">
                <MessageSquare className="w-8 h-8 text-muted-foreground/30" />
                <p className="text-muted-foreground text-sm">No conversations found.</p>
              </div>
            ) : (
              <div className="divide-y divide-sidebar-border">
                {data?.data?.map(conv => (
                  <div 
                    key={conv.id} 
                    onClick={() => setLocation(`/conversations/${conv.id}`)}
                    className="p-4 hover:bg-muted/50 cursor-pointer transition-colors relative"
                  >
                    <div className="flex justify-between items-start mb-1">
                      <h3 className="font-semibold text-sm truncate pr-4">
                        {conv.customerName || conv.customerPhone || `Unknown (${conv.customerId})`}
                      </h3>
                      <span className="text-[10px] text-muted-foreground whitespace-nowrap">
                        {conv.lastMessageAt ? new Date(conv.lastMessageAt).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'}) : ''}
                      </span>
                    </div>
                    <p className="text-xs text-muted-foreground line-clamp-2 pr-6 mb-2">
                      {conv.lastMessagePreview || 'No messages yet.'}
                    </p>
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-1.5">
                        {conv.status === 'ai_handled' ? (
                          <Badge variant="outline" className="text-[9px] py-0 px-1 border-primary/30 text-primary bg-primary/5 flex items-center gap-1">
                            <Bot className="w-3 h-3" /> AI Active
                          </Badge>
                        ) : conv.status === 'human_handled' ? (
                          <Badge variant="outline" className="text-[9px] py-0 px-1 border-blue-500/30 text-blue-500 bg-blue-500/5 flex items-center gap-1">
                            <User className="w-3 h-3" /> Agent
                          </Badge>
                        ) : (
                          <Badge variant="secondary" className="text-[9px] py-0 px-1 uppercase">{conv.status}</Badge>
                        )}
                      </div>
                      {conv.unreadCount ? (
                        <div className="w-5 h-5 bg-primary rounded-full flex items-center justify-center text-[10px] font-bold text-primary-foreground">
                          {conv.unreadCount}
                        </div>
                      ) : null}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* Empty state for desktop right panel when just on /conversations */}
        <div className="hidden md:flex flex-1 items-center justify-center bg-muted/20">
          <div className="text-center">
            <div className="w-16 h-16 bg-muted rounded-full flex items-center justify-center mx-auto mb-4">
              <MessageSquare className="w-8 h-8 text-muted-foreground/50" />
            </div>
            <h2 className="text-lg font-medium text-foreground">Select a conversation</h2>
            <p className="text-sm text-muted-foreground mt-1">Choose a thread from the list to start messaging.</p>
          </div>
        </div>
      </div>
    </AppLayout>
  );
}
