import React from 'react';
import { AppLayout } from '../components/layout';
import { 
  useGetDashboardKpis,
  useGetDashboardActivity,
  useGetDashboardMessageStats,
  useGetDashboardCampaignStatus
} from '@workspace/api-client-react';
import { Card, CardContent, CardHeader, CardTitle } from '../components/ui-elements';
import { Users, Send, MessageSquare, Activity, ArrowUpRight } from 'lucide-react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';

export function Dashboard() {
  const { data: kpis, isLoading: kpisLoading } = useGetDashboardKpis();
  const { data: activity } = useGetDashboardActivity({ limit: 10 });
  const { data: stats } = useGetDashboardMessageStats();
  const { data: campaignStatus } = useGetDashboardCampaignStatus();

  return (
    <AppLayout>
      <div className="p-8 max-w-7xl mx-auto space-y-8">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Command Center</h1>
          <p className="text-muted-foreground text-sm mt-1">Real-time overview of your WhatsApp operations.</p>
        </div>

        {kpisLoading ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            {[1, 2, 3, 4].map(i => <div key={i} className="h-28 bg-muted animate-pulse rounded-sm" />)}
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            <KpiCard title="Active Conversations" value={kpis?.activeConversations} icon={MessageSquare} trend="+12%" />
            <KpiCard title="Messages Sent Today" value={kpis?.messagesSentToday} icon={Send} trend="+5.2%" />
            <KpiCard title="Total Customers" value={kpis?.totalCustomers} icon={Users} trend={kpis?.newCustomersThisMonth ? `+${kpis.newCustomersThisMonth} this month` : ''} />
            <KpiCard title="Delivery Rate" value={kpis?.deliveryRate !== undefined ? `${(kpis.deliveryRate * 100).toFixed(1)}%` : '0%'} icon={Activity} />
          </div>
        )}

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <Card className="lg:col-span-2">
            <CardHeader>
              <CardTitle>Message Volume (7 Days)</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="h-80">
                {stats && stats.length > 0 ? (
                  <ResponsiveContainer width="100%" height="100%">
                    <LineChart data={stats} margin={{ top: 5, right: 20, bottom: 5, left: 0 }}>
                      <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#e2e8f0" />
                      <XAxis dataKey="date" axisLine={false} tickLine={false} tick={{ fontSize: 12, fill: '#64748b' }} dy={10} />
                      <YAxis axisLine={false} tickLine={false} tick={{ fontSize: 12, fill: '#64748b' }} />
                      <Tooltip contentStyle={{ borderRadius: '2px', border: '1px solid #e2e8f0', fontSize: '14px', fontFamily: 'monospace' }} />
                      <Line type="monotone" dataKey="sent" stroke="#1fcc7b" strokeWidth={2} dot={false} activeDot={{ r: 6 }} />
                      <Line type="monotone" dataKey="delivered" stroke="#3b82f6" strokeWidth={2} dot={false} />
                    </LineChart>
                  </ResponsiveContainer>
                ) : (
                  <div className="h-full flex items-center justify-center text-muted-foreground text-sm">No data available</div>
                )}
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Campaign Status</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="h-64 flex items-center justify-center relative">
                {campaignStatus && campaignStatus.length > 0 ? (
                  <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                      <Pie
                        data={campaignStatus}
                        cx="50%"
                        cy="50%"
                        innerRadius={60}
                        outerRadius={80}
                        paddingAngle={2}
                        dataKey="count"
                        nameKey="status"
                      >
                        {campaignStatus.map((entry, index) => {
                          const colors: Record<string, string> = {
                            running: '#1fcc7b',
                            completed: '#3b82f6',
                            draft: '#cbd5e1',
                            scheduled: '#f59e0b',
                            paused: '#f59e0b',
                            failed: '#ef4444'
                          };
                          return <Cell key={`cell-${index}`} fill={colors[entry.status.toLowerCase()] || '#cbd5e1'} />;
                        })}
                      </Pie>
                      <Tooltip formatter={(value: number, name: string) => [value, name.charAt(0).toUpperCase() + name.slice(1)]} />
                    </PieChart>
                  </ResponsiveContainer>
                ) : (
                  <div className="h-full flex items-center justify-center text-muted-foreground text-sm">No campaigns</div>
                )}
              </div>
              <div className="mt-4 space-y-2">
                {campaignStatus?.map(s => (
                  <div key={s.status} className="flex items-center justify-between text-sm">
                    <span className="capitalize text-muted-foreground">{s.status}</span>
                    <span className="font-mono font-medium">{s.count}</span>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>Recent Activity</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {activity && activity.length > 0 ? activity.map((item) => (
                <div key={item.id} className="flex items-start gap-4 pb-4 border-b border-card-border/50 last:border-0 last:pb-0">
                  <div className="w-8 h-8 rounded-full bg-muted flex items-center justify-center shrink-0">
                    <Activity className="w-4 h-4 text-muted-foreground" />
                  </div>
                  <div className="flex-1">
                    <p className="text-sm font-medium">{item.title}</p>
                    <p className="text-xs text-muted-foreground mt-0.5">{item.description}</p>
                  </div>
                  <span className="text-xs text-muted-foreground whitespace-nowrap">
                    {new Date(item.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                  </span>
                </div>
              )) : (
                <div className="text-sm text-muted-foreground py-4">No recent activity</div>
              )}
            </div>
          </CardContent>
        </Card>
      </div>
    </AppLayout>
  );
}

function KpiCard({ title, value, icon: Icon, trend }: { title: string, value: string | number | undefined, icon: any, trend?: string }) {
  return (
    <Card>
      <CardContent className="p-6">
        <div className="flex items-center justify-between">
          <span className="text-sm font-medium text-muted-foreground">{title}</span>
          <Icon className="w-4 h-4 text-muted-foreground" />
        </div>
        <div className="mt-4 flex items-baseline gap-2">
          <span className="text-3xl font-bold font-mono tracking-tight">{value !== undefined ? value : '-'}</span>
          {trend && (
            <span className="text-xs font-medium text-primary flex items-center">
              {trend.startsWith('+') && <ArrowUpRight className="w-3 h-3 mr-0.5" />}
              {trend}
            </span>
          )}
        </div>
      </CardContent>
    </Card>
  );
}
