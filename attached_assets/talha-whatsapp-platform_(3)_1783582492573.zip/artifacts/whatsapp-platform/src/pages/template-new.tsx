import React, { useState } from 'react';
import { useLocation } from 'wouter';
import { useCreateTemplate, TemplateInputCategory } from '@workspace/api-client-react';
import { AppLayout } from '../components/layout';
import { Card, CardContent, CardHeader, CardTitle, Button, Input, Select, Textarea } from '../components/ui-elements';

export function TemplateNew() {
  const [, setLocation] = useLocation();
  const [formData, setFormData] = useState({
    name: '',
    category: 'marketing' as TemplateInputCategory,
    language: 'en_US',
    body: '',
    header: '',
    footer: ''
  });

  const createMutation = useCreateTemplate({
    mutation: {
      onSuccess: () => {
        setLocation('/templates');
      }
    }
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    createMutation.mutate({
      data: {
        name: formData.name.toLowerCase().replace(/[^a-z0-9_]/g, '_'), // format for WA
        category: formData.category,
        language: formData.language,
        body: formData.body,
        header: formData.header || undefined,
        footer: formData.footer || undefined
      }
    });
  };

  return (
    <AppLayout>
      <div className="p-8 max-w-5xl mx-auto space-y-6">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Create Template</h1>
          <p className="text-muted-foreground text-sm mt-1">Design a new WhatsApp message template for approval.</p>
        </div>

        <form onSubmit={handleSubmit} className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          <div className="space-y-6">
            <Card>
              <CardHeader><CardTitle>Template Settings</CardTitle></CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <label className="text-sm font-medium">Template Name</label>
                  <Input 
                    value={formData.name} 
                    onChange={e => setFormData({ ...formData, name: e.target.value })} 
                    placeholder="e.g. summer_sale_promo"
                    required
                  />
                  <p className="text-[10px] text-muted-foreground">Lowercase, numbers, and underscores only.</p>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <label className="text-sm font-medium">Category</label>
                    <Select value={formData.category} onChange={e => setFormData({ ...formData, category: e.target.value as any })}>
                      <option value="marketing">Marketing</option>
                      <option value="utility">Utility</option>
                      <option value="authentication">Authentication</option>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <label className="text-sm font-medium">Language</label>
                    <Select value={formData.language} onChange={e => setFormData({ ...formData, language: e.target.value })}>
                      <option value="en_US">English (US)</option>
                      <option value="en_GB">English (UK)</option>
                      <option value="es">Spanish</option>
                      <option value="pt">Portuguese</option>
                    </Select>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader><CardTitle>Content Builder</CardTitle></CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <label className="text-sm font-medium">Header (Optional text)</label>
                  <Input 
                    value={formData.header} 
                    onChange={e => setFormData({ ...formData, header: e.target.value })} 
                    placeholder="e.g. Special Offer!"
                    maxLength={60}
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-medium">Body *</label>
                  <Textarea 
                    value={formData.body} 
                    onChange={e => setFormData({ ...formData, body: e.target.value })} 
                    placeholder="Hello {{1}}, we have a special offer for you..."
                    className="min-h-[150px] font-mono text-sm"
                    required
                  />
                  <p className="text-[10px] text-muted-foreground">Use {'{{1}}'}, {'{{2}}'} for variables.</p>
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-medium">Footer (Optional)</label>
                  <Input 
                    value={formData.footer} 
                    onChange={e => setFormData({ ...formData, footer: e.target.value })} 
                    placeholder="e.g. Reply STOP to unsubscribe"
                    maxLength={60}
                  />
                </div>
              </CardContent>
            </Card>
            
            <Button type="submit" className="w-full" disabled={createMutation.isPending}>
              {createMutation.isPending ? 'Submitting...' : 'Submit for Approval'}
            </Button>
          </div>

          <div className="lg:sticky lg:top-8 h-fit">
            <h3 className="text-sm font-medium mb-4 text-muted-foreground uppercase tracking-widest">WhatsApp Preview</h3>
            <div className="bg-[#e5ddd5] rounded-xl p-4 shadow-inner max-w-sm mx-auto relative overflow-hidden border-8 border-gray-900">
              <div className="absolute top-0 inset-x-0 h-10 bg-[#075e54] flex items-center px-4">
                <div className="flex gap-2 items-center">
                  <div className="w-6 h-6 rounded-full bg-white/20"></div>
                  <span className="text-white font-medium text-sm">Business Name</span>
                </div>
              </div>
              <div className="mt-12 space-y-2">
                <div className="bg-white rounded-lg rounded-tl-none p-3 shadow-sm max-w-[85%] relative pb-6">
                  {formData.header && <h4 className="font-bold text-sm mb-1">{formData.header}</h4>}
                  <p className="text-[14px] whitespace-pre-wrap leading-tight text-gray-800">
                    {formData.body || 'Type your message body to see preview...'}
                  </p>
                  {formData.footer && <p className="text-[11px] text-gray-500 mt-2 uppercase">{formData.footer}</p>}
                  <span className="absolute bottom-1 right-2 text-[10px] text-gray-400">12:00</span>
                </div>
              </div>
            </div>
          </div>
        </form>
      </div>
    </AppLayout>
  );
}
