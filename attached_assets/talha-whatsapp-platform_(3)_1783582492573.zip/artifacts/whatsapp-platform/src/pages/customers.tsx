import React, { useState } from 'react';
import { Link, useLocation } from 'wouter';
import { useListCustomers, useDeleteCustomer, getListCustomersQueryKey, ListCustomersStatus } from '@workspace/api-client-react';
import { useQueryClient } from '@tanstack/react-query';
import { AppLayout } from '../components/layout';
import { 
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
  Badge, Button, Input, Select, Card, CardContent 
} from '../components/ui-elements';
import { Search, Plus, Filter, MoreHorizontal, Eye, Trash2 } from 'lucide-react';

export function Customers() {
  const [, setLocation] = useLocation();
  const queryClient = useQueryClient();
  const [search, setSearch] = useState('');
  const [status, setStatus] = useState<ListCustomersStatus | ''>('');
  const [page, setPage] = useState(1);

  const { data, isLoading } = useListCustomers({
    search: search || undefined,
    status: (status as ListCustomersStatus) || undefined,
    page,
    limit: 10
  });

  const deleteMutation = useDeleteCustomer({
    mutation: {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getListCustomersQueryKey() });
      }
    }
  });

  const handleDelete = (id: number) => {
    if (confirm('Are you sure you want to delete this customer?')) {
      deleteMutation.mutate({ id });
    }
  };

  return (
    <AppLayout>
      <div className="p-8 max-w-7xl mx-auto space-y-6">
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
          <div>
            <h1 className="text-2xl font-bold tracking-tight">Customers</h1>
            <p className="text-muted-foreground text-sm mt-1">Manage your contacts and audience segments.</p>
          </div>
          <Button onClick={() => alert('Import UI not implemented in mock')}>
            <Plus className="w-4 h-4 mr-2" />
            Add Customer
          </Button>
        </div>

        <Card>
          <CardContent className="p-0">
            <div className="p-4 border-b border-card-border flex flex-col sm:flex-row gap-4">
              <div className="relative flex-1">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                <Input 
                  placeholder="Search by name, phone or email..." 
                  className="pl-9"
                  value={search}
                  onChange={(e) => setSearch(e.target.value)}
                />
              </div>
              <div className="flex gap-2 items-center">
                <Filter className="w-4 h-4 text-muted-foreground" />
                <Select value={status} onChange={(e) => setStatus(e.target.value as any)} className="w-40">
                  <option value="">All Statuses</option>
                  <option value="active">Active</option>
                  <option value="inactive">Inactive</option>
                  <option value="blocked">Blocked</option>
                </Select>
              </div>
            </div>

            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Name</TableHead>
                  <TableHead>Phone</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Tags</TableHead>
                  <TableHead>Last Contacted</TableHead>
                  <TableHead className="w-[100px]"></TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {isLoading ? (
                  <TableRow>
                    <TableCell colSpan={6} className="text-center py-8 text-muted-foreground">Loading customers...</TableCell>
                  </TableRow>
                ) : data?.data?.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={6} className="text-center py-8 text-muted-foreground">No customers found.</TableCell>
                  </TableRow>
                ) : (
                  data?.data?.map((customer) => (
                    <TableRow key={customer.id}>
                      <TableCell className="font-medium">
                        {customer.name}
                        {customer.email && <div className="text-xs text-muted-foreground font-normal">{customer.email}</div>}
                      </TableCell>
                      <TableCell className="font-mono text-sm">{customer.phone}</TableCell>
                      <TableCell>
                        <Badge variant={
                          customer.status === 'active' ? 'success' : 
                          customer.status === 'blocked' ? 'destructive' : 'secondary'
                        }>
                          {customer.status}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        <div className="flex gap-1 flex-wrap">
                          {customer.tags?.slice(0, 2).map(tag => (
                            <Badge key={tag} variant="outline" className="text-[10px] py-0">{tag}</Badge>
                          ))}
                          {(customer.tags?.length || 0) > 2 && (
                            <Badge variant="outline" className="text-[10px] py-0">+{customer.tags!.length - 2}</Badge>
                          )}
                        </div>
                      </TableCell>
                      <TableCell className="text-sm text-muted-foreground">
                        {customer.lastContactedAt ? new Date(customer.lastContactedAt).toLocaleDateString() : 'Never'}
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center gap-2 justify-end">
                          <Button variant="ghost" size="icon" onClick={() => setLocation(`/customers/${customer.id}`)}>
                            <Eye className="w-4 h-4 text-muted-foreground" />
                          </Button>
                          <Button variant="ghost" size="icon" onClick={() => handleDelete(customer.id)}>
                            <Trash2 className="w-4 h-4 text-destructive opacity-50 hover:opacity-100" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
            
            {data && data.total > 0 && (
              <div className="p-4 border-t border-card-border flex items-center justify-between text-sm">
                <span className="text-muted-foreground">
                  Showing {((page - 1) * data.limit) + 1} to {Math.min(page * data.limit, data.total)} of {data.total}
                </span>
                <div className="flex gap-2">
                  <Button variant="outline" size="sm" disabled={page === 1} onClick={() => setPage(p => p - 1)}>Previous</Button>
                  <Button variant="outline" size="sm" disabled={page * data.limit >= data.total} onClick={() => setPage(p => p + 1)}>Next</Button>
                </div>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </AppLayout>
  );
}
