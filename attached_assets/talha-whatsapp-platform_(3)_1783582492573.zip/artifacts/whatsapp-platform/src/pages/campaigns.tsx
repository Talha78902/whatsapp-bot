import React, { useState } from 'react';
import { Link, useLocation } from 'wouter';
import { useListCampaigns, usePauseCampaign, useResumeCampaign, useCancelCampaign, getListCampaignsQueryKey, ListCampaignsStatus } from '@workspace/api-client-react';
import { useQueryClient } from '@tanstack/react-query';
import { AppLayout } from '../components/layout';
import { 
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
  Badge, Button, Card, CardContent 
} from '../components/ui-elements';
import { Search, Plus, Play, Pause, XCircle, BarChart, Copy } from 'lucide-react';

export function Campaigns() {
  const [, setLocation] = useLocation();
  const queryClient = useQueryClient();
  const [activeTab, setActiveTab] = useState<ListCampaignsStatus | 'all'>('all');
  const [page, setPage] = useState(1);

  const { data, isLoading } = useListCampaigns({
    status: activeTab === 'all' ? undefined : activeTab,
    page,
    limit: 10
  });

  const pauseMutation = usePauseCampaign({
    mutation: { onSuccess: () => queryClient.invalidateQueries({ queryKey: getListCampaignsQueryKey() }) }
  });
  const resumeMutation = useResumeCampaign({
    mutation: { onSuccess: () => queryClient.invalidateQueries({ queryKey: getListCampaignsQueryKey() }) }
  });
  const cancelMutation = useCancelCampaign({
    mutation: { onSuccess: () => queryClient.invalidateQueries({ queryKey: getListCampaignsQueryKey() }) }
  });

  const handleAction = (id: number, action: 'pause' | 'resume' | 'cancel') => {
    if (action === 'pause') pauseMutation.mutate({ id });
    if (action === 'resume') resumeMutation.mutate({ id });
    if (action === 'cancel' && confirm('Are you sure you want to cancel this campaign?')) cancelMutation.mutate({ id });
  };

  const tabs: { label: string, value: ListCampaignsStatus | 'all' }[] = [
    { label: 'All', value: 'all' },
    { label: 'Running', value: 'running' },
    { label: 'Scheduled', value: 'scheduled' },
    { label: 'Drafts', value: 'draft' },
    { label: 'Completed', value: 'completed' },
  ];

  return (
    <AppLayout>
      <div className="p-8 max-w-7xl mx-auto space-y-6">
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
          <div>
            <h1 className="text-2xl font-bold tracking-tight">Campaigns</h1>
            <p className="text-muted-foreground text-sm mt-1">Broadcast messages to customer segments.</p>
          </div>
          <Button onClick={() => setLocation('/campaigns/new')}>
            <Plus className="w-4 h-4 mr-2" />
            New Campaign
          </Button>
        </div>

        <Card>
          <CardContent className="p-0">
            <div className="border-b border-card-border overflow-x-auto">
              <div className="flex px-4 min-w-max">
                {tabs.map(tab => (
                  <button
                    key={tab.value}
                    onClick={() => { setActiveTab(tab.value); setPage(1); }}
                    className={`px-4 py-3 text-sm font-medium border-b-2 transition-colors ${
                      activeTab === tab.value 
                        ? 'border-primary text-foreground' 
                        : 'border-transparent text-muted-foreground hover:text-foreground hover:border-border'
                    }`}
                  >
                    {tab.label}
                  </button>
                ))}
              </div>
            </div>

            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Campaign Name</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Delivery Rate</TableHead>
                  <TableHead>Read Rate</TableHead>
                  <TableHead>Scheduled / Sent</TableHead>
                  <TableHead className="w-[140px] text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {isLoading ? (
                  <TableRow>
                    <TableCell colSpan={6} className="text-center py-8 text-muted-foreground">Loading campaigns...</TableCell>
                  </TableRow>
                ) : data?.data?.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={6} className="text-center py-8 text-muted-foreground">No campaigns found in this view.</TableCell>
                  </TableRow>
                ) : (
                  data?.data?.map((campaign) => {
                    const deliveryRate = campaign.recipientCount ? Math.round(((campaign.deliveredCount || 0) / campaign.recipientCount) * 100) : 0;
                    const readRate = campaign.deliveredCount ? Math.round(((campaign.readCount || 0) / campaign.deliveredCount) * 100) : 0;

                    return (
                      <TableRow key={campaign.id}>
                        <TableCell>
                          <Link href={`/campaigns/${campaign.id}`} className="font-medium hover:underline flex items-center gap-2">
                            {campaign.name}
                          </Link>
                          {campaign.type && <span className="text-xs text-muted-foreground capitalize mt-0.5 block">{campaign.type} message</span>}
                        </TableCell>
                        <TableCell>
                          <Badge variant={
                            campaign.status === 'running' ? 'success' : 
                            campaign.status === 'completed' ? 'default' :
                            campaign.status === 'failed' ? 'destructive' :
                            campaign.status === 'scheduled' ? 'warning' : 'secondary'
                          }>
                            {campaign.status}
                          </Badge>
                        </TableCell>
                        <TableCell>
                          <div className="flex items-center gap-2">
                            <div className="w-16 h-1.5 bg-muted rounded-full overflow-hidden">
                              <div className="h-full bg-primary" style={{ width: `${deliveryRate}%` }}></div>
                            </div>
                            <span className="text-xs font-mono">{deliveryRate}%</span>
                          </div>
                        </TableCell>
                        <TableCell>
                          <div className="flex items-center gap-2">
                            <div className="w-16 h-1.5 bg-muted rounded-full overflow-hidden">
                              <div className="h-full bg-blue-500" style={{ width: `${readRate}%` }}></div>
                            </div>
                            <span className="text-xs font-mono">{readRate}%</span>
                          </div>
                        </TableCell>
                        <TableCell className="text-sm text-muted-foreground font-mono">
                          {campaign.startedAt ? new Date(campaign.startedAt).toLocaleString() : 
                           campaign.scheduledAt ? new Date(campaign.scheduledAt).toLocaleString() : '-'}
                        </TableCell>
                        <TableCell>
                          <div className="flex items-center gap-1 justify-end">
                            {campaign.status === 'running' && (
                              <Button variant="ghost" size="icon" title="Pause" onClick={() => handleAction(campaign.id, 'pause')}>
                                <Pause className="w-4 h-4 text-warning" />
                              </Button>
                            )}
                            {campaign.status === 'paused' && (
                              <Button variant="ghost" size="icon" title="Resume" onClick={() => handleAction(campaign.id, 'resume')}>
                                <Play className="w-4 h-4 text-success" />
                              </Button>
                            )}
                            {['scheduled', 'running', 'paused'].includes(campaign.status) && (
                              <Button variant="ghost" size="icon" title="Cancel" onClick={() => handleAction(campaign.id, 'cancel')}>
                                <XCircle className="w-4 h-4 text-destructive" />
                              </Button>
                            )}
                            <Button variant="ghost" size="icon" title="View Analytics" onClick={() => setLocation(`/campaigns/${campaign.id}`)}>
                              <BarChart className="w-4 h-4 text-muted-foreground" />
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    );
                  })
                )}
              </TableBody>
            </Table>
            
            {data && data.total > 0 && (
              <div className="p-4 border-t border-card-border flex items-center justify-between text-sm">
                <span className="text-muted-foreground">
                  Showing {((page - 1) * data.limit) + 1} to {Math.min(page * data.limit, data.total)} of {data.total}
                </span>
                <div className="flex gap-2">
                  <Button variant="outline" size="sm" disabled={page === 1} onClick={() => setPage(p => p - 1)}>Previous</Button>
                  <Button variant="outline" size="sm" disabled={page * data.limit >= data.total} onClick={() => setPage(p => p + 1)}>Next</Button>
                </div>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </AppLayout>
  );
}
