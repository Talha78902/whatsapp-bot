import React, { useState } from 'react';
import { Link, useLocation } from 'wouter';
import { useListTemplates, getListTemplatesQueryKey, ListTemplatesCategory, useDeleteTemplate } from '@workspace/api-client-react';
import { useQueryClient } from '@tanstack/react-query';
import { AppLayout } from '../components/layout';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow, Badge, Button, Card, CardContent } from '../components/ui-elements';
import { Plus, Trash2, LayoutTemplate } from 'lucide-react';

export function Templates() {
  const [, setLocation] = useLocation();
  const queryClient = useQueryClient();
  const [category, setCategory] = useState<ListTemplatesCategory | 'all'>('all');
  
  const { data, isLoading } = useListTemplates({
    category: category === 'all' ? undefined : category,
    limit: 50
  });

  const deleteMutation = useDeleteTemplate({
    mutation: { onSuccess: () => queryClient.invalidateQueries({ queryKey: getListTemplatesQueryKey() }) }
  });

  const handleDelete = (id: number) => {
    if (confirm('Delete this template? Note: This deletes it locally, ensure it is also removed from WhatsApp Business Manager if needed.')) {
      deleteMutation.mutate({ id });
    }
  };

  return (
    <AppLayout>
      <div className="p-8 max-w-7xl mx-auto space-y-6">
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
          <div>
            <h1 className="text-2xl font-bold tracking-tight">Message Templates</h1>
            <p className="text-muted-foreground text-sm mt-1">Pre-approved templates for initiating conversations.</p>
          </div>
          <Button onClick={() => setLocation('/templates/new')}>
            <Plus className="w-4 h-4 mr-2" />
            New Template
          </Button>
        </div>

        <Card>
          <CardContent className="p-0">
            <div className="border-b border-card-border overflow-x-auto p-2">
              <div className="flex gap-2">
                {['all', 'marketing', 'utility', 'authentication'].map(cat => (
                  <Button 
                    key={cat} 
                    variant={category === cat ? 'default' : 'ghost'} 
                    size="sm"
                    className="capitalize"
                    onClick={() => setCategory(cat as any)}
                  >
                    {cat}
                  </Button>
                ))}
              </div>
            </div>

            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Template Name</TableHead>
                  <TableHead>Category / Lang</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Preview</TableHead>
                  <TableHead className="w-[100px]"></TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {isLoading ? (
                  <TableRow><TableCell colSpan={5} className="text-center py-8 text-muted-foreground">Loading...</TableCell></TableRow>
                ) : data?.data?.length === 0 ? (
                  <TableRow><TableCell colSpan={5} className="text-center py-8 text-muted-foreground">No templates found.</TableCell></TableRow>
                ) : (
                  data?.data?.map((template) => (
                    <TableRow key={template.id}>
                      <TableCell className="font-medium font-mono text-sm">{template.name}</TableCell>
                      <TableCell>
                        <div className="text-sm capitalize">{template.category}</div>
                        <div className="text-xs text-muted-foreground uppercase">{template.language}</div>
                      </TableCell>
                      <TableCell>
                        <Badge variant={
                          template.status === 'approved' ? 'success' : 
                          template.status === 'rejected' ? 'destructive' : 'warning'
                        }>
                          {template.status}
                        </Badge>
                      </TableCell>
                      <TableCell className="max-w-xs truncate text-xs text-muted-foreground font-mono">
                        {template.body.substring(0, 50)}...
                      </TableCell>
                      <TableCell>
                        <Button variant="ghost" size="icon" onClick={() => handleDelete(template.id)}>
                          <Trash2 className="w-4 h-4 text-destructive opacity-50 hover:opacity-100" />
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      </div>
    </AppLayout>
  );
}
