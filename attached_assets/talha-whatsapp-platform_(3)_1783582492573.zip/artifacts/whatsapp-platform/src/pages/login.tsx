import React, { useState } from 'react';
import { useLocation, Link } from 'wouter';
import { useLogin } from '@workspace/api-client-react';
import { AuthLayout } from '../components/layout';
import { Button, Input } from '../components/ui-elements';

export function Login() {
  const [, setLocation] = useLocation();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  
  const loginMutation = useLogin({
    mutation: {
      onSuccess: (data) => {
        localStorage.setItem('access_token', data.accessToken);
        setLocation('/');
      },
      onError: (err: any) => {
        setError(err.message || 'Failed to login');
      }
    }
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    loginMutation.mutate({ data: { email, password } });
  };

  return (
    <AuthLayout>
      <div className="mb-6">
        <h2 className="text-xl font-semibold mb-1">Welcome back</h2>
        <p className="text-sm text-muted-foreground">Enter your credentials to access the command center.</p>
      </div>
      
      <form onSubmit={handleSubmit} className="space-y-4">
        {error && (
          <div className="bg-destructive/10 text-destructive px-3 py-2 rounded-sm text-sm border border-destructive/20">
            {error}
          </div>
        )}
        <div className="space-y-2">
          <label className="text-sm font-medium">Email Address</label>
          <Input 
            type="email" 
            value={email} 
            onChange={(e) => setEmail(e.target.value)} 
            placeholder="operator@talha.com"
            required 
          />
        </div>
        <div className="space-y-2">
          <label className="text-sm font-medium">Password</label>
          <Input 
            type="password" 
            value={password} 
            onChange={(e) => setPassword(e.target.value)} 
            required 
          />
        </div>
        <Button type="submit" className="w-full" disabled={loginMutation.isPending}>
          {loginMutation.isPending ? 'Authenticating...' : 'Sign In'}
        </Button>
      </form>
      
      <div className="mt-6 text-center text-sm">
        <span className="text-muted-foreground">Don't have an account? </span>
        <Link href="/register" className="text-primary font-medium hover:underline">Request Access</Link>
      </div>
    </AuthLayout>
  );
}
