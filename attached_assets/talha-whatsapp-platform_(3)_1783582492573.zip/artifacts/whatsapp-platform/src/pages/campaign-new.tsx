import React, { useState } from 'react';
import { useLocation } from 'wouter';
import { useCreateCampaign, CampaignInputType, useListTemplates } from '@workspace/api-client-react';
import { AppLayout } from '../components/layout';
import { Card, CardContent, CardHeader, CardTitle, Button, Input, Select, Textarea } from '../components/ui-elements';
import { ArrowRight, MessageSquare, Users, CalendarClock, Target } from 'lucide-react';

export function CampaignNew() {
  const [, setLocation] = useLocation();
  const [step, setStep] = useState(1);
  const { data: templatesData } = useListTemplates({ limit: 100 });

  const [formData, setFormData] = useState({
    name: '',
    description: '',
    type: 'template' as CampaignInputType,
    templateId: '',
    message: '',
    tags: ''
  });

  const createMutation = useCreateCampaign({
    mutation: {
      onSuccess: (data) => {
        setLocation(`/campaigns/${data.id}`);
      }
    }
  });

  const handleNext = () => setStep(s => s + 1);
  const handleBack = () => setStep(s => s - 1);

  const handleSubmit = () => {
    createMutation.mutate({
      data: {
        name: formData.name,
        description: formData.description,
        type: formData.type,
        templateId: formData.type === 'template' ? Number(formData.templateId) : undefined,
        message: formData.type === 'text' ? formData.message : undefined,
        tags: formData.tags ? formData.tags.split(',').map(t => t.trim()) : []
      }
    });
  };

  return (
    <AppLayout>
      <div className="p-8 max-w-3xl mx-auto space-y-6">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Create Campaign</h1>
          <p className="text-muted-foreground text-sm mt-1">Configure and launch a new message broadcast.</p>
        </div>

        <div className="flex items-center gap-2 mb-8">
          {[1, 2, 3].map((num) => (
            <React.Fragment key={num}>
              <div className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-bold ${
                step === num ? 'bg-primary text-primary-foreground' :
                step > num ? 'bg-primary/20 text-primary' : 'bg-muted text-muted-foreground'
              }`}>
                {num}
              </div>
              {num < 3 && <div className={`flex-1 h-1 rounded-full ${step > num ? 'bg-primary/20' : 'bg-muted'}`} />}
            </React.Fragment>
          ))}
        </div>

        <Card>
          <CardContent className="p-6">
            {step === 1 && (
              <div className="space-y-6 animate-in fade-in slide-in-from-right-4">
                <div className="flex items-center gap-2 mb-2">
                  <Target className="w-5 h-5 text-primary" />
                  <h2 className="text-lg font-semibold">Basic Details</h2>
                </div>
                <div className="space-y-4">
                  <div className="space-y-2">
                    <label className="text-sm font-medium">Campaign Name *</label>
                    <Input 
                      value={formData.name} 
                      onChange={e => setFormData({ ...formData, name: e.target.value })} 
                      placeholder="e.g. Summer Sale 2024"
                    />
                  </div>
                  <div className="space-y-2">
                    <label className="text-sm font-medium">Description</label>
                    <Textarea 
                      value={formData.description} 
                      onChange={e => setFormData({ ...formData, description: e.target.value })} 
                      placeholder="Internal note about this campaign's goal..."
                      className="min-h-[100px]"
                    />
                  </div>
                </div>
              </div>
            )}

            {step === 2 && (
              <div className="space-y-6 animate-in fade-in slide-in-from-right-4">
                <div className="flex items-center gap-2 mb-2">
                  <MessageSquare className="w-5 h-5 text-primary" />
                  <h2 className="text-lg font-semibold">Message Content</h2>
                </div>
                <div className="space-y-4">
                  <div className="space-y-2">
                    <label className="text-sm font-medium">Message Type</label>
                    <Select 
                      value={formData.type} 
                      onChange={e => setFormData({ ...formData, type: e.target.value as CampaignInputType })}
                    >
                      <option value="template">WhatsApp Template (Recommended for marketing)</option>
                      <option value="text">Plain Text (24h window only)</option>
                    </Select>
                  </div>
                  
                  {formData.type === 'template' ? (
                    <div className="space-y-2 border border-card-border p-4 rounded-sm bg-muted/20 mt-4">
                      <label className="text-sm font-medium">Select Approved Template</label>
                      <Select 
                        value={formData.templateId} 
                        onChange={e => setFormData({ ...formData, templateId: e.target.value })}
                      >
                        <option value="">-- Choose a template --</option>
                        {templatesData?.data?.filter(t => t.status === 'approved').map(t => (
                          <option key={t.id} value={t.id}>{t.name} ({t.language})</option>
                        ))}
                      </Select>
                      <p className="text-xs text-muted-foreground mt-2">Only approved templates can be used for initial outreach.</p>
                    </div>
                  ) : (
                    <div className="space-y-2 mt-4">
                      <label className="text-sm font-medium">Message Text</label>
                      <Textarea 
                        value={formData.message} 
                        onChange={e => setFormData({ ...formData, message: e.target.value })} 
                        placeholder="Type your message here..."
                        className="min-h-[150px]"
                      />
                      <p className="text-xs text-warning">Warning: Sending arbitrary text is only allowed if the customer has messaged you within the last 24 hours.</p>
                    </div>
                  )}
                </div>
              </div>
            )}

            {step === 3 && (
              <div className="space-y-6 animate-in fade-in slide-in-from-right-4">
                <div className="flex items-center gap-2 mb-2">
                  <Users className="w-5 h-5 text-primary" />
                  <h2 className="text-lg font-semibold">Audience & Launch</h2>
                </div>
                <div className="space-y-4">
                  <div className="space-y-2">
                    <label className="text-sm font-medium">Target Tags (Comma separated)</label>
                    <Input 
                      value={formData.tags} 
                      onChange={e => setFormData({ ...formData, tags: e.target.value })} 
                      placeholder="e.g. VIP, active, summer-lead"
                    />
                    <p className="text-xs text-muted-foreground">Leave empty to target all customers.</p>
                  </div>

                  <div className="bg-muted p-4 rounded-sm mt-6 border border-card-border">
                    <h3 className="font-semibold text-sm mb-2">Review Summary</h3>
                    <ul className="text-sm space-y-1 text-muted-foreground">
                      <li><span className="font-medium text-foreground">Name:</span> {formData.name}</li>
                      <li><span className="font-medium text-foreground">Type:</span> {formData.type}</li>
                      {formData.tags && <li><span className="font-medium text-foreground">Audience:</span> Customers tagged with: {formData.tags}</li>}
                    </ul>
                  </div>
                </div>
              </div>
            )}

            <div className="flex justify-between mt-8 pt-6 border-t border-card-border">
              <Button variant="outline" onClick={handleBack} disabled={step === 1}>
                Back
              </Button>
              {step < 3 ? (
                <Button onClick={handleNext} disabled={!formData.name && step === 1}>
                  Continue <ArrowRight className="w-4 h-4 ml-2" />
                </Button>
              ) : (
                <Button onClick={handleSubmit} disabled={createMutation.isPending}>
                  {createMutation.isPending ? 'Saving Draft...' : 'Create Draft'}
                </Button>
              )}
            </div>
          </CardContent>
        </Card>
      </div>
    </AppLayout>
  );
}
