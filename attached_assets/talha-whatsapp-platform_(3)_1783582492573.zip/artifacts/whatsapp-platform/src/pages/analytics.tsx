import React from 'react';
import { useGetAnalyticsOverview, useGetCampaignsAnalytics } from '@workspace/api-client-react';
import { AppLayout } from '../components/layout';
import { Card, CardContent, CardHeader, CardTitle, Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '../components/ui-elements';
import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip, BarChart, Bar, XAxis, YAxis, CartesianGrid } from 'recharts';

export function Analytics() {
  const { data: overview, isLoading: overviewLoading } = useGetAnalyticsOverview();
  const { data: campaigns, isLoading: campaignsLoading } = useGetCampaignsAnalytics();

  return (
    <AppLayout>
      <div className="p-8 max-w-7xl mx-auto space-y-8">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Analytics Overview</h1>
          <p className="text-muted-foreground text-sm mt-1">Deep dive into your WhatsApp business performance.</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          <Card>
            <CardContent className="p-6">
              <span className="text-sm font-medium text-muted-foreground">Total Sent</span>
              <div className="text-3xl font-bold font-mono tracking-tight mt-2">{overview?.totalMessagesSent?.toLocaleString() || 0}</div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-6">
              <span className="text-sm font-medium text-muted-foreground">Delivered</span>
              <div className="text-3xl font-bold font-mono tracking-tight mt-2">{overview?.totalMessagesDelivered?.toLocaleString() || 0}</div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-6">
              <span className="text-sm font-medium text-muted-foreground">Avg Delivery Rate</span>
              <div className="text-3xl font-bold font-mono tracking-tight mt-2 text-primary">
                {overview?.avgDeliveryRate ? (overview.avgDeliveryRate * 100).toFixed(1) : 0}%
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-6">
              <span className="text-sm font-medium text-muted-foreground">Avg Read Rate</span>
              <div className="text-3xl font-bold font-mono tracking-tight mt-2 text-blue-500">
                {overview?.avgReadRate ? (overview.avgReadRate * 100).toFixed(1) : 0}%
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <Card className="lg:col-span-1">
            <CardHeader>
              <CardTitle>Delivery Breakdown</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="h-64">
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie
                      data={[
                        { name: 'Read', value: overview?.totalMessagesRead || 0 },
                        { name: 'Delivered Unread', value: (overview?.totalMessagesDelivered || 0) - (overview?.totalMessagesRead || 0) },
                        { name: 'Failed', value: overview?.totalMessagesFailed || 0 }
                      ]}
                      innerRadius={60}
                      outerRadius={80}
                      paddingAngle={2}
                      dataKey="value"
                    >
                      <Cell fill="#3b82f6" /> {/* Read */}
                      <Cell fill="#1fcc7b" /> {/* Delivered */}
                      <Cell fill="#ef4444" /> {/* Failed */}
                    </Pie>
                    <Tooltip formatter={(value: number) => value.toLocaleString()} />
                  </PieChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>

          <Card className="lg:col-span-2">
            <CardHeader>
              <CardTitle>Top Campaigns by Read Rate</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="h-64">
                {campaigns?.topPerforming && campaigns.topPerforming.length > 0 ? (
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={campaigns.topPerforming.slice(0, 5)} layout="vertical" margin={{ left: 0, right: 20 }}>
                      <CartesianGrid strokeDasharray="3 3" horizontal={true} vertical={false} />
                      <XAxis type="number" hide />
                      <YAxis dataKey="name" type="category" width={150} tick={{fontSize: 12}} axisLine={false} tickLine={false} />
                      <Tooltip formatter={(value: number) => [`${(value * 100).toFixed(1)}%`, 'Read Rate']} />
                      <Bar dataKey="readRate" fill="#3b82f6" radius={[0, 4, 4, 0]} />
                    </BarChart>
                  </ResponsiveContainer>
                ) : (
                  <div className="h-full flex items-center justify-center text-muted-foreground text-sm">Not enough data</div>
                )}
              </div>
            </CardContent>
          </Card>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>Campaign Performance Log</CardTitle>
          </CardHeader>
          <CardContent className="p-0">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Campaign Name</TableHead>
                  <TableHead className="text-right">Sent</TableHead>
                  <TableHead className="text-right">Delivered</TableHead>
                  <TableHead className="text-right">Read</TableHead>
                  <TableHead className="text-right">Read Rate</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {campaignsLoading ? (
                  <TableRow><TableCell colSpan={5} className="text-center py-4">Loading...</TableCell></TableRow>
                ) : (
                  campaigns?.campaigns?.map(c => (
                    <TableRow key={c.id}>
                      <TableCell className="font-medium">{c.name}</TableCell>
                      <TableCell className="text-right font-mono">{c.sent.toLocaleString()}</TableCell>
                      <TableCell className="text-right font-mono">{c.delivered.toLocaleString()}</TableCell>
                      <TableCell className="text-right font-mono">{c.read.toLocaleString()}</TableCell>
                      <TableCell className="text-right font-mono">{(c.readRate * 100).toFixed(1)}%</TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      </div>
    </AppLayout>
  );
}
