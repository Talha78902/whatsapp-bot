import React, { useState, useEffect, useRef } from 'react';
import { useRoute } from 'wouter';
import { 
  useGetConversation, useListConversationMessages, useSendConversationMessage, 
  useHandoffConversation, useCloseConversation, getGetConversationQueryKey, getListConversationMessagesQueryKey 
} from '@workspace/api-client-react';
import { useQueryClient } from '@tanstack/react-query';
import { AppLayout } from '../components/layout';
import { Button, Input, Badge } from '../components/ui-elements';
import { Send, Bot, User, Check, CheckCheck, Clock, X, AlertCircle } from 'lucide-react';

export function ConversationDetail() {
  const [, params] = useRoute('/conversations/:id');
  const id = Number(params?.id);
  const queryClient = useQueryClient();
  const scrollRef = useRef<HTMLDivElement>(null);
  const [message, setMessage] = useState('');

  const { data: conv } = useGetConversation(id, { query: { enabled: !!id, refetchInterval: 5000, queryKey: getGetConversationQueryKey(id) }});
  const { data: msgs } = useListConversationMessages({ limit: 100 }, { query: { enabled: !!id, refetchInterval: 5000, queryKey: getListConversationMessagesQueryKey(id) }});

  const sendMutation = useSendConversationMessage({
    mutation: {
      onSuccess: () => {
        setMessage('');
        queryClient.invalidateQueries({ queryKey: getListConversationMessagesQueryKey(id) });
      }
    }
  });

  const handoffMutation = useHandoffConversation({ mutation: { onSuccess: () => queryClient.invalidateQueries({ queryKey: getGetConversationQueryKey(id) })}});
  const closeMutation = useCloseConversation({ mutation: { onSuccess: () => queryClient.invalidateQueries({ queryKey: getGetConversationQueryKey(id) })}});

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [msgs?.data]);

  const handleSend = (e: React.FormEvent) => {
    e.preventDefault();
    if (!message.trim()) return;
    sendMutation.mutate({ id, data: { type: 'text', content: message }});
  };

  if (!conv) return <AppLayout><div className="flex h-screen items-center justify-center">Loading...</div></AppLayout>;

  return (
    <AppLayout>
      <div className="flex flex-col h-screen max-w-4xl mx-auto border-x border-sidebar-border bg-card">
        {/* Header */}
        <div className="h-16 border-b border-sidebar-border flex items-center justify-between px-6 bg-background shrink-0">
          <div>
            <h2 className="font-semibold">{conv.customerName || conv.customerPhone}</h2>
            <div className="flex items-center gap-2 mt-0.5">
              <Badge variant={conv.status === 'closed' ? 'secondary' : 'default'} className="text-[10px] py-0 px-1 uppercase h-4">
                {conv.status.replace('_', ' ')}
              </Badge>
              {conv.isAiEnabled && (
                <span className="text-[10px] text-primary flex items-center gap-1 font-medium bg-primary/10 px-1.5 rounded-sm">
                  <Bot className="w-3 h-3" /> AI Active
                </span>
              )}
            </div>
          </div>
          <div className="flex gap-2">
            {conv.status !== 'human_handled' && conv.status !== 'closed' && (
              <Button variant="outline" size="sm" onClick={() => handoffMutation.mutate({ id })} disabled={handoffMutation.isPending}>
                <User className="w-4 h-4 mr-2" /> Take Over
              </Button>
            )}
            {conv.status !== 'closed' && (
              <Button variant="destructive" size="sm" onClick={() => closeMutation.mutate({ id })} disabled={closeMutation.isPending}>
                <X className="w-4 h-4 mr-2" /> Close
              </Button>
            )}
          </div>
        </div>

        {/* Message Thread */}
        <div className="flex-1 overflow-y-auto p-4 space-y-4 bg-muted/10 relative" ref={scrollRef}>
          {msgs?.data?.length === 0 ? (
            <div className="h-full flex items-center justify-center text-muted-foreground text-sm">No messages yet.</div>
          ) : (
            msgs?.data?.slice().reverse().map(m => {
              const isOutbound = m.direction === 'outbound';
              return (
                <div key={m.id} className={`flex flex-col ${isOutbound ? 'items-end' : 'items-start'}`}>
                  <div className={`max-w-[80%] rounded-2xl px-4 py-2 ${
                    isOutbound ? 'bg-primary text-primary-foreground rounded-tr-sm' : 'bg-muted text-foreground rounded-tl-sm'
                  }`}>
                    <p className="text-sm whitespace-pre-wrap">{m.content}</p>
                  </div>
                  <div className={`flex items-center gap-1 mt-1 px-1 ${isOutbound ? 'justify-end' : 'justify-start'}`}>
                    <span className="text-[10px] text-muted-foreground">
                      {new Date(m.createdAt).toLocaleTimeString([], {hour: '2-digit', minute: '2-digit'})}
                    </span>
                    {isOutbound && m.isAiGenerated && <Bot className="w-3 h-3 text-muted-foreground/50" />}
                    {isOutbound && m.status === 'sent' && <Check className="w-3 h-3 text-muted-foreground" />}
                    {isOutbound && m.status === 'delivered' && <CheckCheck className="w-3 h-3 text-muted-foreground" />}
                    {isOutbound && m.status === 'read' && <CheckCheck className="w-3 h-3 text-blue-500" />}
                    {isOutbound && m.status === 'failed' && <AlertCircle className="w-3 h-3 text-destructive" />}
                  </div>
                </div>
              );
            })
          )}
        </div>

        {/* Input Area */}
        <div className="p-4 border-t border-sidebar-border bg-background shrink-0">
          {conv.status === 'closed' ? (
            <div className="text-center text-sm text-muted-foreground py-2">
              This conversation is closed.
            </div>
          ) : (
            <form onSubmit={handleSend} className="flex gap-2">
              <Input 
                className="flex-1 bg-muted/50 border-transparent focus-visible:ring-1 focus-visible:bg-background"
                placeholder="Type a message..."
                value={message}
                onChange={e => setMessage(e.target.value)}
                autoFocus
              />
              <Button type="submit" disabled={!message.trim() || sendMutation.isPending} size="icon">
                <Send className="w-4 h-4" />
              </Button>
            </form>
          )}
        </div>
      </div>
    </AppLayout>
  );
}
