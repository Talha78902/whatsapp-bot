import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { Toaster } from '@/components/ui/toaster';
import { TooltipProvider } from '@/components/ui/tooltip';
import NotFound from '@/pages/not-found';
import { Route, Switch, Router as WouterRouter } from 'wouter';
import { setAuthTokenGetter } from '@workspace/api-client-react';

// Initialize auth getter for API client
setAuthTokenGetter(() => localStorage.getItem('access_token'));

const queryClient = new QueryClient();

import { Login } from './pages/login';
import { Register } from './pages/register';
import { Dashboard } from './pages/dashboard';
import { Customers } from './pages/customers';
import { CustomerDetail } from './pages/customer-detail';
import { Campaigns } from './pages/campaigns';
import { CampaignNew } from './pages/campaign-new';
import { CampaignDetail } from './pages/campaign-detail';
import { Templates } from './pages/templates';
import { TemplateNew } from './pages/template-new';
import { Conversations } from './pages/conversations';
import { ConversationDetail } from './pages/conversation-detail';
import { Analytics } from './pages/analytics';
import { Settings } from './pages/settings';

function Router() {
  return (
    <Switch>
      <Route path="/login" component={Login} />
      <Route path="/register" component={Register} />
      <Route path="/" component={Dashboard} />
      <Route path="/customers" component={Customers} />
      <Route path="/customers/:id" component={CustomerDetail} />
      <Route path="/campaigns" component={Campaigns} />
      <Route path="/campaigns/new" component={CampaignNew} />
      <Route path="/campaigns/:id" component={CampaignDetail} />
      <Route path="/templates" component={Templates} />
      <Route path="/templates/new" component={TemplateNew} />
      <Route path="/conversations" component={Conversations} />
      <Route path="/conversations/:id" component={ConversationDetail} />
      <Route path="/analytics" component={Analytics} />
      <Route path="/settings" component={Settings} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, '')}>
          <Router />
        </WouterRouter>
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
