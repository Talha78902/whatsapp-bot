import React, { useEffect } from 'react';
import { Link, useLocation } from 'wouter';
import { cn } from './ui-elements';
import { 
  LayoutDashboard, Users, MessageSquare, 
  Send, FileText, BarChart3, Settings, 
  LogOut, PhoneCall
} from 'lucide-react';
import { useGetMe } from '@workspace/api-client-react';

export function Sidebar() {
  const [location, setLocation] = useLocation();
  const { data: user, isLoading, error } = useGetMe({ query: { retry: false } });

  useEffect(() => {
    // If not loading and we got an error (e.g. 401), redirect to login
    if (!isLoading && error) {
      setLocation('/login');
    }
  }, [error, isLoading, setLocation]);

  const navItems = [
    { href: '/', label: 'Dashboard', icon: LayoutDashboard },
    { href: '/conversations', label: 'Conversations', icon: MessageSquare },
    { href: '/customers', label: 'Customers', icon: Users },
    { href: '/campaigns', label: 'Campaigns', icon: Send },
    { href: '/templates', label: 'Templates', icon: FileText },
    { href: '/analytics', label: 'Analytics', icon: BarChart3 },
  ];

  const handleLogout = () => {
    localStorage.removeItem('access_token');
    setLocation('/login');
  };

  return (
    <div className="flex flex-col w-64 bg-sidebar text-sidebar-foreground h-screen border-r border-sidebar-border">
      <div className="h-14 flex items-center px-4 border-b border-sidebar-border gap-2">
        <PhoneCall className="w-5 h-5 text-primary" />
        <span className="font-bold tracking-tight text-sm uppercase">Talha Command</span>
      </div>
      <div className="flex-1 py-4 overflow-y-auto">
        <nav className="space-y-1 px-2">
          {navItems.map((item) => {
            const isActive = location === item.href || (item.href !== '/' && location.startsWith(item.href));
            return (
              <Link key={item.href} href={item.href} className={cn(
                "flex items-center gap-3 px-3 py-2 rounded-sm text-sm font-medium transition-colors",
                isActive ? "bg-sidebar-accent text-sidebar-accent-foreground" : "hover:bg-sidebar-accent/50 text-sidebar-foreground/70 hover:text-sidebar-foreground"
              )}>
                <item.icon className="w-4 h-4" />
                {item.label}
              </Link>
            );
          })}
        </nav>
      </div>
      <div className="p-4 border-t border-sidebar-border">
        <div className="flex items-center gap-3 mb-4 px-2">
          <div className="w-8 h-8 rounded-sm bg-primary/20 flex items-center justify-center text-primary font-bold shrink-0">
            {user?.name?.charAt(0) || 'U'}
          </div>
          <div className="flex flex-col overflow-hidden">
            <span className="text-sm font-medium truncate">{user?.name || 'Loading...'}</span>
            <span className="text-xs text-sidebar-foreground/50 truncate capitalize">{user?.role || 'operator'}</span>
          </div>
        </div>
        <Link href="/settings" className={cn(
          "flex items-center gap-3 px-3 py-2 rounded-sm text-sm font-medium transition-colors mb-1",
          location.startsWith('/settings') ? "bg-sidebar-accent text-sidebar-accent-foreground" : "hover:bg-sidebar-accent/50 text-sidebar-foreground/70"
        )}>
          <Settings className="w-4 h-4" />
          Settings
        </Link>
        <button onClick={handleLogout} className="w-full flex items-center gap-3 px-3 py-2 rounded-sm text-sm font-medium transition-colors hover:bg-destructive/20 text-destructive hover:text-destructive">
          <LogOut className="w-4 h-4" />
          Logout
        </button>
      </div>
    </div>
  );
}

export function AppLayout({ children }: { children: React.ReactNode }) {
  return (
    <div className="flex h-screen overflow-hidden bg-background">
      <Sidebar />
      <main className="flex-1 overflow-y-auto">
        {children}
      </main>
    </div>
  );
}

export function AuthLayout({ children }: { children: React.ReactNode }) {
  return (
    <div className="min-h-screen bg-sidebar flex flex-col justify-center items-center p-4 relative">
      <div className="absolute inset-0 bg-gradient-to-b from-transparent to-sidebar/90 z-0"></div>
      <div className="w-full max-w-md relative z-10">
        <div className="flex items-center justify-center gap-2 mb-8">
          <div className="w-10 h-10 bg-primary flex items-center justify-center rounded-sm">
            <PhoneCall className="w-6 h-6 text-primary-foreground" />
          </div>
          <h1 className="text-2xl font-bold tracking-tight text-white uppercase">Talha Command</h1>
        </div>
        <div className="bg-card text-card-foreground p-8 rounded-sm shadow-xl border border-card-border">
          {children}
        </div>
      </div>
    </div>
  );
}
