# Talha WhatsApp Business Platform

## Overview

A production-ready full-stack WhatsApp Business Management Platform built with React + Vite (frontend) and Express 5 + Drizzle ORM + PostgreSQL (backend).

## Architecture

### Monorepo Structure (pnpm workspaces)

```
/
├── artifacts/
│   ├── api-server/       — Express 5 REST API (port from $PORT, default 8080)
│   └── whatsapp-platform/ — React + Vite frontend (Tailwind CSS v4, shadcn/ui)
├── lib/
│   ├── db/               — Drizzle ORM schema + PostgreSQL connection
│   ├── api-spec/         — OpenAPI 3.1 spec (openapi.yaml)
│   ├── api-client-react/ — Orval-generated React Query hooks
│   └── api-zod/          — Orval-generated Zod validation schemas
```

### Tech Stack

- **Frontend:** React 18, Vite 7, Tailwind CSS v4, shadcn/ui, Recharts, Wouter
- **Backend:** Express 5, TypeScript, Drizzle ORM, PostgreSQL
- **Auth:** JWT (access 15m / refresh 7d) + bcrypt (cost 12)
- **API:** OpenAPI 3.1 spec-first, Orval codegen for hooks and Zod schemas

## Features

- **Dashboard** — KPI cards, message volume chart, campaign status pie, activity feed
- **Customers** — Full CRUD, import, tags, notes, status management
- **Campaigns** — Multi-step creation wizard, schedule/pause/resume/cancel/duplicate, analytics
- **Templates** — WhatsApp template management with live phone preview
- **Conversations** — Inbox with AI/human handoff, real-time message thread
- **Analytics** — Delivery rates, message timeline, top-performing campaigns
- **Settings** — Meta WhatsApp API config, AI auto-responder tuning
- **Webhooks** — WhatsApp webhook verify + inbound message ingestion

## Running the Project

Both services start automatically via Replit workflows.

### Manual start

```bash
# API server
pnpm --filter @workspace/api-server run dev

# Frontend
pnpm --filter @workspace/whatsapp-platform run dev
```

## Default Admin Credentials

- **Email:** admin@talha.com
- **Password:** Admin@1234

⚠️ Change this password immediately after first login in production.

## Environment Variables

| Variable | Required | Description |
|---|---|---|
| `DATABASE_URL` | ✅ | PostgreSQL connection string |
| `SESSION_SECRET` | ✅ | Used as JWT signing secret |
| `JWT_SECRET` | Optional | Overrides SESSION_SECRET for JWT |

## Database

Schema managed via Drizzle ORM. Tables: `users`, `customers`, `customer_notes`, `campaigns`, `templates`, `conversations`, `conversation_messages`, `settings`, `activity_logs`.

To push schema changes:
```bash
pnpm --filter @workspace/db run push
```

To regenerate API client after OpenAPI changes:
```bash
pnpm --filter @workspace/api-client-react run generate
pnpm --filter @workspace/api-zod run generate
```

## User Preferences

- Use Express 5 + Drizzle ORM + PostgreSQL (not NestJS/Prisma)
- JWT + bcrypt auth (as specified in PRD)
- OpenAPI-first development with Orval codegen
- Never use `Math.random()` in durable CodeExecution contexts
