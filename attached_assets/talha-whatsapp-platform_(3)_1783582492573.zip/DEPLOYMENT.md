# Talha WhatsApp Business Platform — Full Deployment Guide

## Overview
Three services to deploy, in this order:
1. **Database** → Neon.tech (free PostgreSQL, 2 min)
2. **API Server** → Railway (free Node.js hosting, 5 min)
3. **Frontend** → Vercel (free static hosting, 3 min)

---

## STEP 1 — Push to GitHub (required by Railway + Vercel)

```bash
# Extract the zip, then inside the project folder:
git init
git add .
git commit -m "Initial commit"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/YOUR_REPO.git
git push -u origin main
```

Create a new **empty** repo at https://github.com/new (do NOT tick "Add README")

---

## STEP 2 — Create the Database (Neon.tech)

1. Go to https://neon.tech → Sign up free
2. Click **New Project** → name it `talha-whatsapp`
3. Click **Create Project**
4. Copy the **Connection string** — it looks like:
   `postgresql://user:pass@ep-xxx.us-east-1.aws.neon.tech/neondb?sslmode=require`
5. **Save this** — you need it in the next step

---

## STEP 3 — Deploy the API on Railway

1. Go to https://railway.app → Sign up / Login with GitHub
2. Click **New Project** → **Deploy from GitHub repo**
3. Select your repo
4. Railway detects `railway.json` automatically — click **Deploy**
5. Once deployed, go to your service → **Variables** tab → add:

| Variable | Value |
|---|---|
| `DATABASE_URL` | your Neon connection string from Step 2 |
| `JWT_SECRET` | any random string, 32+ characters |
| `SESSION_SECRET` | another random string, 32+ characters |
| `NODE_ENV` | `production` |
| `PORT` | `8080` |

6. Go to **Settings** → **Networking** → **Generate Domain**
   → You get a URL like `https://talha-api.up.railway.app`
   → **Save this URL**

7. Run database setup (one time only) — in Railway → your service → **Shell**:
```bash
pnpm --filter @workspace/db run push
node -e "
import('./artifacts/api-server/dist/seed-admin.mjs').catch(()=>
  import('./artifacts/api-server/dist/index.mjs').then(()=>{})
)
" 2>/dev/null || node artifacts/api-server/dist/seed-admin.mjs
```
Or run it locally:
```bash
DATABASE_URL="your-neon-url" JWT_SECRET="your-secret" SESSION_SECRET="your-secret" \
  node artifacts/api-server/dist/seed-admin.mjs
# Creates: admin@talha.com / Admin@1234
```

---

## STEP 4 — Deploy the Frontend on Vercel

1. Go to https://vercel.com → Sign up / Login with GitHub
2. Click **Add New Project** → import your GitHub repo
3. Vercel detects `vercel.json` — leave all settings as-is
4. Before clicking Deploy, add **Environment Variables**:

| Variable | Value |
|---|---|
| `VITE_API_BASE_URL` | `https://talha-api.up.railway.app` (your Railway URL from Step 3) |
| `BASE_PATH` | `/` |
| `PORT` | `3000` |

5. Click **Deploy**
6. Your app is live at `https://your-project.vercel.app` 🎉

---

## STEP 5 — First Login & WhatsApp Setup

1. Open your Vercel URL
2. Login: `admin@talha.com` / `Admin@1234`
3. **Change the password immediately** → Settings → Security
4. Go to **Settings → WhatsApp** and enter:
   - Phone Number ID
   - WhatsApp Business Account ID
   - Access Token
   - Webhook Verify Token (any string you choose)
5. In Meta Developer Console → WhatsApp → Webhooks:
   - Callback URL: `https://talha-api.up.railway.app/api/webhooks/whatsapp`
   - Verify Token: same string from above

---

## Costs
- Neon: **Free** (0.5 GB storage)
- Railway: **Free** ($5/month credit, enough for a prototype)
- Vercel: **Free** (hobby plan)

Total: **$0/month** for a prototype
